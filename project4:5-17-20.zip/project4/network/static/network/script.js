

  window.addEventListener("load", function(){
    checkthis = window.location.href;
    checkthissub = checkthis.split("/")[3];
    if (checkthissub === "viewuser") {
    vuserid = document.getElementById('follow').value;
    console.log(vuserid);
    followbtn = document.querySelector('#follow');
    followbtn.addEventListener('click', function follow(){
      fetch('/follow/'+vuserid, {
        method: 'PUT',
        body: JSON.stringify({
        user: "following"
      })

    });})}



    if (checkthis === "http://127.0.0.1:8000/") {
      createbtn = document.querySelector('#newpost');

      createbtn.addEventListener('click',
  function newpost() {
    check = document.querySelector('#inputcontainer')
    if (check === null){
      var x = document.createElement("INPUT");
      x.setAttribute("type", "text");
      x.setAttribute("id", "postinput");
      var y = document.createElement("button");
      y.innerHTML = "Submit";
      y.addEventListener('click', function post() {
        var posttext = document.querySelector('#postinput').value;

        // submit post to Database
        fetch('/newpost', {
          method: 'POST',
          body: JSON.stringify({
          newpost: posttext
        })
      })
      var newpost = document.createElement("div");
      var likesec = document.createElement("div");
      var likebtn = document.createElement("button");
      var dislikebtn = document.createElement("button");

      likebtn.innerHTML = "Like";
      dislikebtn.innerHTML = "Dislike";

      newpost.setAttribute("class", "post");
      likesec.setAttribute("class", "likesec");
      likebtn.setAttribute("class", "likebtn");
      dislikebtn.setAttribute("class", "dislikebtn");


      newpost.innerHTML =  posttext;
      likesec.append(likebtn);
      likesec.append(dislikebtn);
      newpost.append(likesec);
      document.querySelector('#postcontainer').prepend(newpost);

      document.querySelector('#empty').style.display = "none";
      document.querySelector('#inputcontainer').remove();


      })
      var z = document.createElement("div")
      z.setAttribute("id", "inputcontainer");
      z.prepend(x);
      z.prepend(y);
      document.querySelector('#postcontainer').prepend(z);

      }
    });
    }





if (checkthis === "http://127.0.0.1:8000/" || checkthissub === "viewuser" || checkthissub === "public" || checkthissub === "following") {

  document.getElementsByName('comment_text').forEach(item => {
    var c_id = item.id.split("/").pop();
    item.addEventListener('click', function(){
      var comment_input = this;
      if (comment_input.rows === 6) {return};
      var submit_button = document.createElement("button");
      submit_button.addEventListener('mousedown', function() {
              var comment_text = document.getElementById('new_comment/'+ c_id).value;
              fetch('/update/'+c_id, {
                method: 'PUT',
                body: JSON.stringify({
                commented: comment_text,
              })
            }).then(response => response.json())
            .then(data => { if (data.status === "true"){
              comment_input.value = "";
              var comment_sec = document.getElementById('comment_sec/'+c_id);
              var new_comment = document.createElement("div");
              new_comment.innerHTML = comment_text;
              comment_sec.append(new_comment);
            }});
          });
      submit_button.innerHTML = "Submit Comment";
      submit_button.id = "subtn";
      var parent = this.parentNode;
      parent.append(submit_button);
      comment_input.rows = 6;
      comment_input.focus();
      comment_input.setSelectionRange(0,0);
      comment_input.addEventListener('focusout', function (){
            var smbtn = document.getElementById("subtn");
            if (smbtn != null){
                smbtn.remove();
            };
            comment_input.rows = 1;

})
})
})

document.querySelectorAll(".see_comments").forEach(item => {
  item.addEventListener('click', function(){
    var commentbtn = this;
    const post_id = commentbtn.id.split("/").pop();
    var comment_count = 0;
    fetch('/update/'+post_id, {
      method: 'GET',
  }).then(response => response.json())
  .then(data => {
    var comment_sec = document.getElementById('comment_sec/'+post_id);
    comments_text = data;
    for (i = 0; i < comments_text.length; i++) {
      var new_comment = document.createElement("p")
      new_comment.innerHTML = comments_text[i].usersname+"|"+comments_text[i].text+"<br>"+comments_text[i].time;
      comment_sec.append(new_comment);
    }
  });// end of last then response
})//end of event listener
});



document.querySelectorAll('.editbtn').forEach(item => {
  item.addEventListener('click', function(){
    var updated = function updated(editableText, postKepper, newText) {
      postKepper.innerHTML = newText;
      editableText.replaceWith(postKepper);
  };
        var editbtn = this;
        var post_id = editbtn.id.split("/").pop();
        var post_text = document.getElementById(['text/'+post_id]);
        var postKepper = post_text.cloneNode();
        var editableText = document.createElement("textarea");

        editableText.value = post_text.innerHTML;
        editableText.id = 'cEditText';
        post_text.replaceWith(editableText);
        editableText.focus();
        editableText.setSelectionRange(0,0);
        editableText.addEventListener('blur', function (){
          var newText = editableText.value;
          if (event.target.id === 'cEditText'){ updated(editableText, postKepper, newText) ;}});
        // update post edit button
        //fetch('/update'+post_id, {
        //  method: 'POST',
        //  body: JSON.stringify({
        //  edit: true
        //})
      //})

  })
});

  document.querySelectorAll('.likebtn').forEach(item => {
    item.addEventListener('click', function(){
      post_id = this.id.split("/").pop()
      update = this.innerHTML.split("</i>").pop();
      var regExp = /\(([^)]+)\)/;
      var matches = regExp.exec(update);
      const thumbs_up_icon = '<i style="font-size:24px" class="fa">&#xf087;</i>'
      // update like button
      fetch('/update/'+post_id, {
        method: 'PUT',
        body: JSON.stringify({
        like: "true"
      })
    }).then(response => response.json())
    .then(data => { if (data.status === "true"){
      like_count = matches[1] =+ 1;
      this.innerHTML = thumbs_up_icon + "("+like_count+")";
     }//end of if statment
    else if (data.status === "false") {
      like_count = matches[1] =- 1;
      if (like_count < 0){ like_count = 0;}
      this.innerHTML = thumbs_up_icon + "("+like_count+")";

    } // end of else
    });// end of last then response


    })
  });


  document.querySelectorAll('.dislikebtn').forEach(item => {
    item.addEventListener('click', function(){
      post_id = this.id.split("/").pop()
      update = this.innerHTML.split("</i>").pop();
      var regExp = /\(([^)]+)\)/;
      var matches = regExp.exec(update);
      const thumbs_down_icon = '<i style="font-size:24px" class="fa">&#xf165;</i>'
      // update like button
      fetch('/update/'+post_id, {
        method: 'PUT',
        body: JSON.stringify({
        dislike: "true"
      })
    }).then(response => response.json())
    .then(data => { if (data.status === "true"){
      like_count = matches[1] =+ 1;
      this.innerHTML = thumbs_down_icon + "("+like_count+")";
     }//end of if statment
    else if (data.status === "false") {
      like_count = matches[1] =- 1;
      if (like_count < 0){ like_count = 0;}
      this.innerHTML = thumbs_down_icon + "("+like_count+")";

    } // end of else
    });// end of last then response
    })

  });//end of query seletor all




} //end of check if view has post



}

)
