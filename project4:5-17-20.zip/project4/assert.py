def is_int(i):
    try:
        isinstance(i, int)
        print(True)
    except :
        print(False)
